//
//  CarosalCell.swift
//  InstaFeedDemo
//
//  Created by Hiren on 07/03/18.
//  Copyright © 2018 Hiren. All rights reserved.
//

import UIKit
import VGPlayer
import AVKit

class CarosalCell: UITableViewCell,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var lblCaption: UILabel!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var clsFeed: UICollectionView!
    
    var arrGallryData:NSMutableArray = NSMutableArray()
    var player = VGPlayer()
    var currentPlayIndexPath : IndexPath?
    var playerViewSize : CGSize?
    var playerView : VGEmbedPlayerView!
    var smallScreenView : UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        pageControl.currentPage = 0
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func reloadData(){
        clsFeed.delegate = self
        clsFeed.dataSource = self
        addTableViewObservers()
    }
    
    //MARK Collcationview delegate methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        pageControl.numberOfPages = arrGallryData.count
        return arrGallryData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let collectionViewWidth = collectionView.bounds.size.width
        return CGSize(width: collectionViewWidth, height: 250)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let type = (arrGallryData.object(at: indexPath.row) as AnyObject).value(forKey: "type") as! String
        if type == "image"{
            let colfeedcell = collectionView.dequeueReusableCell(withReuseIdentifier: "clsFeedCell", for: indexPath) as! clsFeedCell
            let imageDic = (arrGallryData.object(at: indexPath.row) as AnyObject).value(forKey: "images") as! NSDictionary
            //print(arrGallryData)
            let imageURL = imageDic.value(forKey: "standard_resolution") as! NSDictionary
            let image:String = imageURL.value(forKey: "url") as! String
            colfeedcell.imgClsFeed.sd_setImage(with: URL(string: image), placeholderImage: UIImage(named: "placeholder.png"))
            
            return colfeedcell
        }
        else if type == "video"
        {
            let colVideoCell = collectionView.dequeueReusableCell(withReuseIdentifier: "clsVideoFeedCell", for: indexPath) as! clsVideoFeedCell
            let videoDic = (arrGallryData.object(at: indexPath.row) as AnyObject).value(forKey: "videos") as! NSDictionary
            let videoURl:String = (videoDic.value(forKey: "standard_resolution") as! NSDictionary).value(forKey: "url") as! String
            
            colVideoCell.indexPath = indexPath
            colVideoCell.playCallBack = ({ [weak self] (indexPath: IndexPath?) -> Void in
                guard let strongSelf = self else { return }
                strongSelf.playerViewSize = colVideoCell.videoViewCls.bounds.size
                strongSelf.addPlayer(colVideoCell)
                self?.player.replaceVideo(URL(string:videoURl)!)
                self?.player.displayView.fullscreenButton.isHidden = true
                self?.player.displayView.titleLabel.isHidden = true
                self?.player.displayView.playButtion.isHidden = true
                self?.player.displayView.timeSlider.isHidden = true
                self?.player.displayView.timeLabel.isHidden = true
                self?.player.displayView.closeButton.isHidden = true
                self?.player.play()
                strongSelf.currentPlayIndexPath = indexPath
            })
            return colVideoCell
        }
        return UICollectionViewCell();
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        self.pageControl.currentPage = indexPath.row
    }
    
    var tableViewContext = 0
    func addTableViewObservers() {
        let options = NSKeyValueObservingOptions([.new, .initial])
        clsFeed?.addObserver(self, forKeyPath: #keyPath(UITableView.contentOffset), options: options, context: &tableViewContext)
    }
    
    func addPlayer(_ cell: UICollectionViewCell) {
        if player != nil {
            player.cleanPlayer()
        }
        configurePlayer()
        cell.contentView.addSubview(player.displayView)
        player.displayView.snp.makeConstraints {
            $0.edges.equalTo(cell)
        }
        
        //        player.replaceVideo(URL(string:"https://scontent.cdninstagram.com/vp/6468f32b77b91110ff2be801bdbb2137/5AA9DDBF/t50.2886-16/28689489_584327481920976_5589074893149646794_n.mp4")!)
        //        player.play()
    }
    
    func configurePlayer() {
        playerView = VGEmbedPlayerView()
        player = VGPlayer(playerView: playerView)
        player.backgroundMode = .suspend
    }
    
    func addSmallScreenView() {
        player.displayView.removeFromSuperview()
        //smallScreenView.removeFromSuperview()
        playerView.isSmallMode = true
        //UIApplication.shared.keyWindow?.addSubview(smallScreenView)
        let smallScreenWidth = (playerViewSize?.width)! / 2
        let smallScreenHeight = (playerViewSize?.height)! / 2
//        smallScreenView.snp.remakeConstraints {
//            $0.bottom.equalTo(self.clsFeed.snp.bottom).offset(-10)
//            $0.right.equalTo(self.clsFeed.snp.right).offset(-10)
//            $0.width.equalTo(smallScreenWidth)
//            $0.height.equalTo(smallScreenHeight)
//        }
        smallScreenView = UIView()
        smallScreenView.addSubview(player.displayView)
        player.displayView.snp.remakeConstraints {
            $0.edges.equalTo(smallScreenView)
        }
    }
    
}
extension CarosalCell {
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        //        if (context == &tableViewContext) {
        //
        if keyPath == #keyPath(UICollectionView.contentOffset) {
            if let playIndexPath = currentPlayIndexPath {
                
                if let cell = clsFeed.cellForItem(at: playIndexPath) {
                    if player.displayView.isFullScreen { return }
                    let visibleCells = clsFeed.visibleCells
                    if visibleCells.contains(cell) {
                        //smallScreenView.removeFromSuperview()
                        cell.contentView.addSubview(player.displayView)
                        player.displayView.snp.remakeConstraints {
                            $0.edges.equalTo(cell)
                        }
                        playerView.isSmallMode = false
                    } else {
                        player.displayView.removeFromSuperview()
                       // player.cleanPlayer()
                        //addSmallScreenView()
                    }
                } else {
//                    if isViewLoaded && (view.window != nil) {
//                        if smallScreenView.superview != UIApplication.shared.keyWindow {
//                            addSmallScreenView()
//                        }
//                    }
                }
            }
        }
    }
}

