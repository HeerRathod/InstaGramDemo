//
//  clsFeedCell.swift
//  InstaFeedDemo
//
//  Created by Hiren on 07/03/18.
//  Copyright © 2018 Hiren. All rights reserved.
//

import UIKit

class clsFeedCell: UICollectionViewCell {
    
    @IBOutlet weak var imgClsFeed: UIImageView!
    
}
