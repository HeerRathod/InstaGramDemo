//
//  clsVideoFeedCell.swift
//  InstaFeedDemo
//
//  Created by Admin on 12/03/18.
//  Copyright © 2018 Hiren. All rights reserved.
//

import UIKit

class clsVideoFeedCell: UICollectionViewCell {
    
    
    @IBOutlet weak var videoViewCls: UIView!
    var playCallBack:((IndexPath?) -> Swift.Void)?
    var indexPath : IndexPath?
    
    @IBAction func btnClicked(_ sender: UIButton) {
        if let callBack = playCallBack {
            callBack(indexPath)
        }
    }
}
