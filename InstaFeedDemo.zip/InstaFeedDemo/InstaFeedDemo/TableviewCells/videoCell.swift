//
//  videoCell.swift
//  InstaFeedDemo
//
//  Created by Admin on 08/03/18.
//  Copyright © 2018 Hiren. All rights reserved.
//

import UIKit

class videoCell: UITableViewCell {

    @IBOutlet weak var placeholderImage: UIImageView!
    @IBOutlet weak var btnPlay: UIButton!
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var lblvideoFeed: UILabel!
    var playCallBack:((IndexPath?) -> Swift.Void)?
    var indexPath : IndexPath?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBAction func playVideo(_ sender: Any) {
        if let callBack = playCallBack {
            callBack(indexPath)
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
