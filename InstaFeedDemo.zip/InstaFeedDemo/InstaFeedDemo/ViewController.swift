//
//  ViewController.swift
//  InstaFeedDemo
//
//  Created by Hiren on 07/03/18.
//  Copyright © 2018 Hiren. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage
import VGPlayer
import SnapKit
import AVKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblInstaFeed: UITableView!
    var arrInstaFeed:NSMutableArray = NSMutableArray()
    var player = VGPlayer()
    var currentPlayIndexPath : IndexPath?
    var playerViewSize : CGSize?
    var playerView : VGEmbedPlayerView!
    var smallScreenView : UIView!
    
    var strNewDataURl:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        self.tblInstaFeed.delegate = self
        self.tblInstaFeed.dataSource = self
        tblInstaFeed.estimatedRowHeight = 250
        tblInstaFeed.rowHeight = UITableViewAutomaticDimension
        
        getFeedDataFromInstaGram()
        //smallScreenView = UIView()
        addTableViewObservers()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getFeedDataFromInstaGram(){
        let urlString:String = "https://api.instagram.com/v1/users/self/media/recent?access_token=7229665670.684a1a6.652a7879713f4a21bc5ac61db565db7d"
        Alamofire.request(urlString).responseJSON { response in
            switch response.result {
            case .success:
                var TempDic:NSDictionary = NSDictionary()
                TempDic = response.value as! NSDictionary
                let DicPagination:NSDictionary = TempDic.value(forKey: "pagination") as! NSDictionary
                self.strNewDataURl = DicPagination.value(forKey: "next_url") as! String
                
                self.arrInstaFeed = (TempDic["data"]! as! NSArray).mutableCopy() as! NSMutableArray
                
                //self.arrInstaFeed.add(temarray)
                if self.arrInstaFeed.count > 0{
                    self.tblInstaFeed.reloadData()
                }
            case .failure(let error):
                print("Failure")
            }
        }
    }
    
    @IBAction func btnLoadMoreMedia(_ sender: UIButton) {
        
    }
    
    //MARK: Tableview delegate methods
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrInstaFeed.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        
     
       
        
        if let type:String = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "type") as? String{

        if type == "image"{
            let imageCell = tableView.dequeueReusableCell(withIdentifier: "SingleImageCell", for: indexPath) as! SingleImageCell
            
            let CaptionDic = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "caption") as! NSDictionary
            let userid = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "user") as! NSDictionary
            let username:String = userid.value(forKey: "username") as! String
            let strCaption:String =  CaptionDic.value(forKey: "text") as! String
            imageCell.lblFeed.text = username + ":" + strCaption
            imageCell.lblFeed.textColor = UIColor.blue
            
            let imageDic = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "images") as! NSDictionary
            let imageURL = imageDic.value(forKey: "standard_resolution") as! NSDictionary
            let image:String = imageURL.value(forKey: "url") as! String
//            let height:Float = (imageDic.value(forKey: "standard_resolution") as! NSDictionary).value(forKey: "height") as! Float
//            let width:Float = (imageDic.value(forKey: "standard_resolution") as! NSDictionary).value(forKey: "width") as! Float
//            imageCell.imgFeed.bounds.size.height = CGFloat(height)
//            imageCell.imgFeed.bounds.size.width = CGFloat(width)
            imageCell.imgFeed.sd_setImage(with: URL(string: image), placeholderImage: UIImage(named: "placeholder.png"))
            
            return imageCell
        }else if type == "video"{
            let videoCell1 = tableView.dequeueReusableCell(withIdentifier: "videoCell", for: indexPath) as! videoCell
            let CaptionDic = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "caption") as! NSDictionary
            let userid = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "user") as! NSDictionary
            let username:String = userid.value(forKey: "username") as! String
            let strCaption:String =  CaptionDic.value(forKey: "text") as! String
            videoCell1.lblvideoFeed.text = username + ":" + strCaption
            videoCell1.lblvideoFeed.textColor = UIColor.blue
            let imageDic = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "images") as! NSDictionary
            let imageURL:String = (imageDic.value(forKey: "standard_resolution") as! NSDictionary).value(forKey: "url") as! String
//            let height:Float = (imageDic.value(forKey: "standard_resolution") as! NSDictionary).value(forKey: "height") as! Float
//            let width:Float = (imageDic.value(forKey: "standard_resolution") as! NSDictionary).value(forKey: "width") as! Float
//            videoCell1.placeholderImage.bounds.size.height = CGFloat(height)
//            videoCell1.placeholderImage.bounds.size.width = CGFloat(width)
            videoCell1.placeholderImage?.sd_setImage(with: URL(string: imageURL), placeholderImage: UIImage(named: "placeholder.png"))
            let videoDic = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "videos") as! NSDictionary
            //print((arrInstaFeed.object(at: indexPath.row) as AnyObject))
            let videoURl:String = (videoDic.value(forKey: "standard_resolution") as! NSDictionary).value(forKey: "url") as! String

            
            videoCell1.indexPath = indexPath
            videoCell1.playCallBack = ({ [weak self] (indexPath: IndexPath?) -> Void in
                guard let strongSelf = self else { return }
                strongSelf.playerViewSize = videoCell1.videoView.bounds.size
                strongSelf.addPlayer(videoCell1)
                self?.player.replaceVideo(URL(string:videoURl)!)
                self?.player.displayView.fullscreenButton.isHidden = true
                self?.player.displayView.titleLabel.isHidden = true
                self?.player.displayView.playButtion.isHidden = true
                self?.player.displayView.timeSlider.isHidden = true
                self?.player.displayView.timeLabel.isHidden = true
                self?.player.displayView.closeButton.isHidden = true
                self?.player.play()
                strongSelf.currentPlayIndexPath = indexPath
            })
            
            return videoCell1
            
        }else if type == "carousel"{
            let CarosalCell = tableView.dequeueReusableCell(withIdentifier: "CarosalCell", for: indexPath) as! CarosalCell
            let CaptionDic = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "caption") as! NSDictionary
            let userid = (arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "user") as! NSDictionary
            let username:String = userid.value(forKey: "username") as! String
            let strCaption:String =  CaptionDic.value(forKey: "text") as! String
            CarosalCell.lblCaption.text = username + ":" + strCaption
            CarosalCell.lblCaption.textColor = UIColor.blue
            
            let arrCarosalData = ((arrInstaFeed.object(at: indexPath.row) as AnyObject).value(forKey: "carousel_media") as! NSArray).mutableCopy() as! NSMutableArray
            CarosalCell.arrGallryData = arrCarosalData
            CarosalCell.reloadData()

            return CarosalCell
        }else{
        }
        }
        return UITableViewCell();
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if ((indexPath.row == self.arrInstaFeed.count - 1) && (self.arrInstaFeed.count % 20 == 0)){
            loadMore()
        }
    }
    
    func loadMore(){
        
        Alamofire.request(self.strNewDataURl).responseJSON { response in
            switch response.result {
            case .success:
                var TempDic:NSDictionary = NSDictionary()
                TempDic = response.value as! NSDictionary
                print(TempDic)
                let PaginationDic:NSDictionary = TempDic.value(forKey: "pagination") as! NSDictionary
                
                if PaginationDic.count > 0{
                    self.strNewDataURl = PaginationDic.value(forKey: "next_url") as! String
                }
                let arrPagination:NSArray = (TempDic.value(forKey: "data") as! NSArray)
                self.arrInstaFeed.addObjects(from: (arrPagination.mutableCopy() as! NSMutableArray) as! [Any])
                self.tblInstaFeed.reloadData()
            case .failure(_):
                print("Failure")
            }}
        
    }

    var tableViewContext = 0
    func addTableViewObservers() {
        let options = NSKeyValueObservingOptions([.new, .initial])
        tblInstaFeed?.addObserver(self, forKeyPath: #keyPath(UITableView.contentOffset), options: options, context: &tableViewContext)
    }
    
    func addPlayer(_ cell: videoCell) {
        if player != nil {
            player.cleanPlayer()
        }
        configurePlayer()
        cell.videoView.addSubview(player.displayView)
        player.displayView.snp.makeConstraints {
            $0.edges.equalTo(cell.videoView)
        }
    }
    
    func configurePlayer() {
        playerView = VGEmbedPlayerView()
        player = VGPlayer(playerView: playerView)
        player.backgroundMode = .suspend
    }
    
    func addSmallScreenView() {
        player.displayView.removeFromSuperview()
        playerView.isSmallMode = true
        let smallScreenWidth = (playerViewSize?.width)! / 2
        let smallScreenHeight = (playerViewSize?.height)! / 2
        smallScreenView = UIView()
        smallScreenView.addSubview(player.displayView)
        player.displayView.snp.remakeConstraints {
            $0.edges.equalTo(smallScreenView)
        }
    }
    
}
extension ViewController {
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        if keyPath == #keyPath(UITableView.contentOffset) {
            if let playIndexPath = currentPlayIndexPath {
                if let cell = tblInstaFeed.cellForRow(at: playIndexPath) {
                    if player.displayView.isFullScreen { return }
                    let visibleCells = tblInstaFeed.visibleCells
                    if visibleCells.contains(cell) {
                        //smallScreenView.removeFromSuperview()
                        cell.contentView.addSubview(player.displayView)
                        player.displayView.snp.remakeConstraints {
                            $0.edges.equalTo(cell)
                        }
                        playerView.isSmallMode = false
                        self.player.play()
                    } else {
                        player.displayView.removeFromSuperview()
                        print("remove player")
//                        player.cleanPlayer()
                        self.player.pause()
//                        self.player.cleanPlayer()
//                        player = VGPlayer()
//                        self.playerView.reloadPlayerView()
                    }
                }
            }
        }
    }
}


